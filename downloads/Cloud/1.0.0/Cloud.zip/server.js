// 2-TEK Standalone Application Server
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const port = parseInt(process.env.PORT || "3018", 10);
const hostname = process.env.HOSTNAME || "0.0.0.0";

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(`<!DOCTYPE html><html><head><title>Cloud Storage</title><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>body{font-family:Inter,sans-serif;margin:0;padding:40px;background:#0d1117;color:#f0f6fc;display:flex;flex-direction:column;align-items:center;justify-content:center;height:80vh;}h1{color:#6938ef;}p{color:#8b949e;}</style></head><body><h1>Cloud Storage</h1><p>Cloud storage manager, file permissions, and cloud resource viewer.</p><p>Port: ${port} | Standalone Build</p></body></html>`);
});

server.listen(port, hostname, () => {
  console.log(`> Cloud Storage running on http://${hostname}:${port}`);
});
