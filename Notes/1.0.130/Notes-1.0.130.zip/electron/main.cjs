/**
 * packages/Notes/electron/main.cjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Notes & Memo Studio — Electron Main Process
 *
 * Provides desktop window lifecycle management, titlebar controls,
 * native file dialogs, and IPC channels for 2-TEK Notes & Memo Studio.
 * Conforms to: Electron Single Try-Catch & Mandatory Error Display Rule
 * ─────────────────────────────────────────────────────────────────────────────
 */

const path = require("node:path");
const http = require("node:http");
const fileSystem = require("node:fs");

function loadElectronModule() {
  try {
    if (typeof global !== "undefined" && global.__notes_electron_mock__) {
      return global.__notes_electron_mock__;
    }
    const loadedModule = require("electron");
    if (typeof loadedModule === "object" && loadedModule !== null) {
      return loadedModule;
    }
    return {};
  } catch (loadError) {
    console.warn(
      "[Notes Electron] Electron module unavailable in current environment:",
      loadError && loadError.message ? loadError.message : loadError
    );
    return {};
  }
}

const electronModule = loadElectronModule();
const { app, BrowserWindow, ipcMain, dialog } = electronModule;

/**
 * Native error dialog helper conforming to single try-catch pattern
 */
function displayElectronError(title = "2-TEK Notes & Memo Studio Error", error = null, detail = "") {
  try {
    const errorMessage =
      error && error.message
        ? error.message
        : typeof error === "string"
        ? error
        : "An unexpected error occurred.";
    const formattedDetail = detail || (error && error.stack ? error.stack : "");

    console.error(
      `[Notes Electron Error] ${title}: ${errorMessage}`,
      formattedDetail ? `\nDetail: ${formattedDetail}` : ""
    );

    const activeDialog =
      (electronModule && electronModule.dialog) ||
      dialog ||
      (typeof global !== "undefined" && global.__notes_electron_dialog__);

    if (activeDialog && typeof activeDialog.showErrorBox === "function") {
      activeDialog.showErrorBox(
        title,
        formattedDetail ? `${errorMessage}\n\n${formattedDetail}` : errorMessage
      );
      return true;
    }

    if (activeDialog && typeof activeDialog.showMessageBoxSync === "function") {
      activeDialog.showMessageBoxSync({
        type: "error",
        title,
        message: title,
        detail: formattedDetail ? `${errorMessage}\n\n${formattedDetail}` : errorMessage,
        buttons: ["OK"],
        noLink: true,
      });
      return true;
    }

    return false;
  } catch (displayException) {
    console.error("[Notes Electron Error] Failed to display native error dialog:", displayException);
    return false;
  }
}

/**
 * Configure application metadata
 */
function configureAppMetadata() {
  try {
    if (app && typeof app.setName === "function") {
      app.setName("2-tek-notes");
    }
    if (app && typeof app.setAppUserModelId === "function") {
      app.setAppUserModelId("com.vtek.notes");
    }
  } catch (metadataError) {
    displayElectronError("Configure Metadata Error", metadataError);
  }
}

configureAppMetadata();

/**
 * Resolve target port (default: 3030)
 */
function resolvePortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsedPort = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsedPort) && parsedPort > 0) {
          return parsedPort;
        }
      }
      if (process.env.NOTES_PORT) {
        const parsedAppPort = parseInt(process.env.NOTES_PORT, 10);
        if (!Number.isNaN(parsedAppPort) && parsedAppPort > 0) {
          return parsedAppPort;
        }
      }
    }

    const appRootDirectory = path.resolve(__dirname, "..");
    const candidateEnvironmentFiles = [
      path.join(appRootDirectory, ".env"),
      path.join(appRootDirectory, ".env.local"),
      path.join(appRootDirectory, ".env.development"),
    ];

    for (const candidateFilePath of candidateEnvironmentFiles) {
      if (fileSystem.existsSync(candidateFilePath)) {
        const fileContentString = fileSystem.readFileSync(candidateFilePath, "utf8");
        const fileLines = fileContentString.split(/\r?\n/);
        for (const singleLine of fileLines) {
          const trimmedLine = singleLine.trim();
          if (trimmedLine.startsWith("#") || !trimmedLine.includes("=")) {
            continue;
          }
          const separatorIndex = trimmedLine.indexOf("=");
          const variableKey = trimmedLine.slice(0, separatorIndex).trim();
          if (variableKey === "PORT" || variableKey === "NOTES_PORT") {
            const rawVariableValue = trimmedLine.slice(separatorIndex + 1).trim();
            const cleanVariableValue = rawVariableValue.replace(/^["']|["']$/g, "");
            const parsedPort = parseInt(cleanVariableValue, 10);
            if (!Number.isNaN(parsedPort) && parsedPort > 0) {
              return parsedPort;
            }
          }
        }
      }
    }
  } catch (portError) {
    console.error("[Notes Electron Error] Failed resolving port from env:", portError);
  }

  return 3030;
}

const TARGET_PORT = resolvePortFromEnv();
const APP_URL = `http://localhost:${TARGET_PORT}`;

let mainWindow = null;
let pendingFileToOpen = null;

// Parse file path passed via command line arguments
if (process.argv && process.argv.length > 1) {
  for (let argumentIndex = 1; argumentIndex < process.argv.length; argumentIndex += 1) {
    const candidateArgument = process.argv[argumentIndex];
    if (
      candidateArgument &&
      !candidateArgument.startsWith("-") &&
      fileSystem.existsSync(candidateArgument) &&
      fileSystem.statSync(candidateArgument).isFile()
    ) {
      pendingFileToOpen = path.resolve(candidateArgument);
      break;
    }
  }
}

/**
 * Register IPC handlers for window controls and native file operations
 */
function registerIpcHandlers() {
  try {
    if (!ipcMain || typeof ipcMain.handle !== "function") {
      return;
    }

    // Window controls
    ipcMain.handle("window:minimize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.minimize();
        return true;
      }
      return false;
    });

    ipcMain.handle("window:maximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        if (mainWindow.isMaximized()) {
          mainWindow.unmaximize();
        } else {
          mainWindow.maximize();
        }
        return true;
      }
      return false;
    });

    ipcMain.handle("window:close", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.close();
        return true;
      }
      return false;
    });

    ipcMain.handle("window:is-maximized", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        return mainWindow.isMaximized();
      }
      return false;
    });

    // Native file dialogs & file system operations
    ipcMain.handle("file:open-dialog", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showOpenDialog !== "function") {
          return { canceled: true };
        }
        const openResult = await dialog.showOpenDialog(mainWindow, {
          title: options.title || "Mở tệp (Open File)",
          defaultPath: options.defaultPath,
          buttonLabel: options.buttonLabel || "Mở (Open)",
          properties: ["openFile"],
          filters: options.filters || [
          {
                    "name": "Notes & Markdown",
                    "extensions": [
                              "md",
                              "txt",
                              "json",
                              "html"
                    ]
          },
          {
                    "name": "All Files",
                    "extensions": [
                              "*"
                    ]
          }
],
        });

        if (openResult.canceled || !openResult.filePaths || openResult.filePaths.length === 0) {
          return { canceled: true };
        }

        const selectedFilePath = openResult.filePaths[0];
        const selectedFileName = path.basename(selectedFilePath);
        const fileContent = await fileSystem.promises.readFile(selectedFilePath, "utf8");

        return {
          canceled: false,
          filePath: selectedFilePath,
          fileName: selectedFileName,
          content: fileContent,
        };
      } catch (openDialogError) {
        displayElectronError("Open File Dialog Error", openDialogError);
        return { canceled: true };
      }
    });

    ipcMain.handle("file:save-dialog", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showSaveDialog !== "function") {
          return { canceled: true };
        }
        const saveResult = await dialog.showSaveDialog(mainWindow, {
          title: options.title || "Lưu tệp (Save File)",
          defaultPath: options.defaultPath || "file",
          buttonLabel: options.buttonLabel || "Lưu (Save)",
          filters: options.filters || [
          {
                    "name": "Notes & Markdown",
                    "extensions": [
                              "md",
                              "txt",
                              "json",
                              "html"
                    ]
          },
          {
                    "name": "All Files",
                    "extensions": [
                              "*"
                    ]
          }
],
        });

        if (saveResult.canceled || !saveResult.filePath) {
          return { canceled: true };
        }

        return {
          canceled: false,
          filePath: saveResult.filePath,
        };
      } catch (saveDialogError) {
        displayElectronError("Save File Dialog Error", saveDialogError);
        return { canceled: true };
      }
    });

    ipcMain.handle("file:read", async (_event, targetFilePath) => {
      try {
        if (!targetFilePath || !fileSystem.existsSync(targetFilePath)) {
          return { success: false, error: "File not found" };
        }
        const fileContentText = await fileSystem.promises.readFile(targetFilePath, "utf8");
        return { success: true, content: fileContentText };
      } catch (readFileError) {
        return { success: false, error: String(readFileError) };
      }
    });

    ipcMain.handle("file:write", async (_event, payload) => {
      try {
        const targetFilePath = payload && payload.targetFilePath;
        const fileContentText = payload && payload.fileContentText;
        if (!targetFilePath) {
          return { success: false, error: "Target file path required" };
        }
        await fileSystem.promises.writeFile(targetFilePath, fileContentText || "", "utf8");
        return { success: true };
      } catch (writeFileError) {
        return { success: false, error: String(writeFileError) };
      }
    });
  } catch (ipcRegistrationError) {
    displayElectronError("Register IPC Handlers Error", ipcRegistrationError);
  }
}

registerIpcHandlers();

const APP_TITLE = "2-TEK Notes & Memo Studio";
const DEFAULT_SPLASH_HTML_CONTENT = `data:text/html;charset=utf-8,${encodeURIComponent(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>2-TEK Notes & Memo Studio</title><style>*{box-sizing:border-box;margin:0;padding:0;}body{margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background-color:#ffffff;background-image:url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" width="1920" height="1080" fill="none"> <defs> <linearGradient id="hub-bg-base" x1="0" y1="0" x2="1920" y2="1080" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23ffffff"/> <stop offset="50%" stop-color="%23f8fafc"/> <stop offset="100%" stop-color="%23f1f5f9"/> </linearGradient> <radialGradient id="hub-bg-aura-purple" cx="50%" cy="45%" r="60%"> <stop offset="0%" stop-color="%236938ef" stop-opacity="0.12"/> <stop offset="50%" stop-color="%23875bf7" stop-opacity="0.05"/> <stop offset="100%" stop-color="%23ffffff" stop-opacity="0"/> </radialGradient> <radialGradient id="hub-bg-aura-cyan" cx="80%" cy="20%" r="45%"> <stop offset="0%" stop-color="%2306b6d4" stop-opacity="0.08"/> <stop offset="100%" stop-color="%23ffffff" stop-opacity="0"/> </radialGradient> <linearGradient id="dragon-stone-grad" x1="60" y1="460" x2="480" y2="120" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23475569"/> <stop offset="45%" stop-color="%236938ef"/> <stop offset="85%" stop-color="%23875bf7"/> <stop offset="100%" stop-color="%2306b6d4"/> </linearGradient> <linearGradient id="dragon-body-fill" x1="100" y1="450" x2="450" y2="150" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23f8fafc" stop-opacity="0.85"/> <stop offset="50%" stop-color="%23f1f5f9" stop-opacity="0.75"/> <stop offset="100%" stop-color="%23ede9fe" stop-opacity="0.65"/> </linearGradient> <pattern id="hub-tech-grid" width="48" height="48" patternUnits="userSpaceOnUse"> <path d="M 48 0 L 0 0 0 48" fill="none" stroke="%236938ef" stroke-width="0.75" stroke-opacity="0.035"/> <circle cx="48" cy="48" r="1.25" fill="%236938ef" fill-opacity="0.06"/> </pattern> <filter id="dragon-shadow" x="-10%" y="-10%" width="120%" height="120%"> <feDropShadow dx="0" dy="6" stdDeviation="12" flood-color="%236938ef" flood-opacity="0.10"/> </filter> </defs> <rect width="1920" height="1080" fill="url(%23hub-bg-base)"/> <rect width="1920" height="1080" fill="url(%23hub-bg-aura-purple)"/> <rect width="1920" height="1080" fill="url(%23hub-bg-aura-cyan)"/> <rect width="1920" height="1080" fill="url(%23hub-tech-grid)"/> <g transform="translate(960, 480) translate(-256, -256) scale(1.64)" opacity="0.22" filter="url(%23dragon-shadow)"> <defs> <linearGradient id="bg-grad" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23ffffff"/> <stop offset="100%" stop-color="%23f0f4ff"/> </linearGradient> <linearGradient id="dragon-grad" x1="60" y1="420" x2="440" y2="80" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%2364748b"/> <stop offset="40%" stop-color="%236938ef"/> <stop offset="80%" stop-color="%23875bf7"/> <stop offset="100%" stop-color="%2322d3ee"/> </linearGradient> <linearGradient id="body-fill" x1="60" y1="420" x2="420" y2="80" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23e8eaf6" stop-opacity="0.9"/> <stop offset="60%" stop-color="%23ede9fe" stop-opacity="0.85"/> <stop offset="100%" stop-color="%23e0f2fe" stop-opacity="0.8"/> </linearGradient> <linearGradient id="stairs-fill" x1="120" y1="440" x2="460" y2="140" gradientUnits="userSpaceOnUse"> <stop offset="0%" stop-color="%23dde3ec"/> <stop offset="100%" stop-color="%23e8ecf3"/> </linearGradient> <filter id="glow-shadow" x="-15%" y="-15%" width="130%" height="130%"> <feDropShadow dx="0" dy="4" stdDeviation="10" flood-color="%236938ef" flood-opacity="0.18"/> </filter> <filter id="badge-inner"> <feGaussianBlur in="SourceAlpha" stdDeviation="12" result="blur"/> <feComposite in="SourceGraphic" in2="blur" operator="over"/> </filter> </defs> <rect width="512" height="512" rx="96" fill="url(%23bg-grad)"/> <rect x="3" y="3" width="506" height="506" rx="93" stroke="%23e2e8f0" stroke-width="3" fill="none"/> <rect x="14" y="14" width="484" height="484" rx="82" stroke="%236938ef" stroke-width="1.5" stroke-opacity="0.12" fill="none"/> <g id="imperial-stairs" opacity="0.82"> <path d="M 60 440 L 140 440 L 140 500 L 60 500 Z" fill="url(%23stairs-fill)" stroke="%2394a3b8" stroke-width="2.5" stroke-linejoin="round"/> <path d="M 140 376 L 220 376 L 220 440 L 140 440 Z" fill="url(%23stairs-fill)" stroke="%2394a3b8" stroke-width="2.5" stroke-linejoin="round"/> <path d="M 220 312 L 300 312 L 300 376 L 220 376 Z" fill="url(%23stairs-fill)" stroke="%2394a3b8" stroke-width="2.5" stroke-linejoin="round"/> <path d="M 300 248 L 380 248 L 380 312 L 300 312 Z" fill="url(%23stairs-fill)" stroke="%2394a3b8" stroke-width="2.5" stroke-linejoin="round"/> <path d="M 380 184 L 460 184 L 460 248 L 380 248 Z" fill="url(%23stairs-fill)" stroke="%2394a3b8" stroke-width="2.5" stroke-linejoin="round"/> <line x1="61" y1="441" x2="139" y2="441" stroke="%23ffffff" stroke-width="2.5"/> <line x1="141" y1="377" x2="219" y2="377" stroke="%23ffffff" stroke-width="2.5"/> <line x1="221" y1="313" x2="299" y2="313" stroke="%23ffffff" stroke-width="2.5"/> <line x1="301" y1="249" x2="379" y2="249" stroke="%23ffffff" stroke-width="2.5"/> <line x1="381" y1="185" x2="459" y2="185" stroke="%23ffffff" stroke-width="2.5"/> <line x1="139" y1="441" x2="139" y2="499" stroke="%238898b0" stroke-width="2"/> <line x1="219" y1="377" x2="219" y2="439" stroke="%238898b0" stroke-width="2"/> <line x1="299" y1="313" x2="299" y2="375" stroke="%238898b0" stroke-width="2"/> <line x1="379" y1="249" x2="379" y2="311" stroke="%238898b0" stroke-width="2"/> <line x1="459" y1="185" x2="459" y2="247" stroke="%238898b0" stroke-width="2"/> </g> <g id="stone-dragon-main" filter="url(%23glow-shadow)"> <path id="dragon-body" d=" M 150 310 C 165 275, 195 245, 225 235 C 255 225, 270 255, 290 275 C 305 290, 320 210, 360 190 C 390 175, 420 195, 450 165 C 462 152, 472 150, 475 158 C 478 166, 468 180, 450 188 C 420 205, 400 270, 360 280 C 335 288, 315 300, 295 285 C 275 270, 260 295, 235 318 C 215 338, 200 360, 190 410 L 175 410 C 175 360, 185 330, 205 308 C 220 290, 240 270, 255 272 C 270 274, 280 288, 295 280 C 310 272, 330 250, 360 250 C 385 250, 405 230, 440 185 C 455 166, 470 155, 478 158 C 468 150, 462 148, 450 160 C 425 188, 392 172, 360 188 C 325 206, 300 278, 282 270 C 264 262, 250 220, 225 230 C 200 240, 172 268, 155 302 Z " fill="url(%23body-fill)" stroke="url(%23dragon-grad)" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round" /> <g id="dorsal-fins" fill="url(%23dragon-grad)" opacity="0.92"> <path d="M 208 242 C 212 226 220 219 227 224 C 232 228 229 240 225 248 Z"/> <path d="M 228 234 C 233 217 242 210 250 216 C 255 220 252 232 247 240 Z"/> <path d="M 250 230 C 256 213 266 207 274 213 C 279 217 275 229 270 237 Z"/> <path d="M 358 198 C 364 180 374 174 382 180 C 387 184 384 196 378 204 Z"/> <path d="M 382 188 C 388 170 400 164 408 171 C 413 175 409 188 403 196 Z"/> <path d="M 406 176 C 413 158 425 153 433 159 C 438 163 434 176 427 184 Z"/> <path d="M 430 165 C 437 148 448 144 456 150 C 460 154 456 166 449 173 Z"/> </g> <g id="body-scales" stroke="url(%23dragon-grad)" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.7"> <path d="M 195 270 C 205 265 218 268 222 278"/> <path d="M 218 278 C 228 273 241 276 245 286"/> <path d="M 238 238 C 248 228 262 232 265 245 C 267 255 258 262 248 258 C 242 256 240 248 245 244"/> <path d="M 360 250 C 372 244 386 248 390 260"/> <path d="M 390 260 C 402 254 416 258 419 270"/> <path d="M 410 190 C 422 180 436 185 438 198 C 440 208 430 215 420 210"/> </g> <g id="dragon-leg"> <path d="M 145 355 C 137 378 132 405 135 438 L 185 438 C 185 420 180 390 170 365 Z" fill="%23dde4ef" stroke="url(%23dragon-grad)" stroke-width="3" stroke-linejoin="round"/> <path d="M 162 390 C 174 385 187 393 190 406 C 182 408 173 403 163 410 Z" fill="url(%23dragon-grad)" opacity="0.85"/> <path d="M 127 438 C 121 429 123 417 131 417 C 138 417 141 428 142 438 Z" fill="url(%23dragon-grad)"/> <path d="M 142 438 C 140 426 146 415 154 415 C 160 416 163 427 163 438 Z" fill="url(%23dragon-grad)"/> <path d="M 163 438 C 164 425 171 414 180 415 C 186 417 186 428 185 438 Z" fill="url(%23dragon-grad)"/> <path d="M 185 438 C 190 427 198 419 205 423 C 209 426 207 434 203 438 Z" fill="url(%23dragon-grad)"/> </g> <g id="dragon-head"> <g id="mane" fill="url(%23dragon-grad)"> <path d="M 148 318 C 180 312 212 328 238 354 C 222 346 204 336 184 340 C 168 344 157 355 148 362 C 151 345 150 332 148 318 Z" opacity="0.78"/> <path d="M 143 286 C 175 270 215 276 246 302 C 226 294 206 290 186 300 C 170 308 160 322 143 326 C 147 310 145 298 143 286 Z" opacity="0.86"/> <path d="M 136 256 C 168 236 210 236 244 258 C 224 254 203 251 183 261 C 168 269 157 283 140 290 C 143 276 141 266 136 256 Z" opacity="0.93"/> <path d="M 128 238 C 148 213 180 208 212 225 C 192 224 176 226 161 237 C 151 245 143 255 135 264 Z"/> </g> <path d="M 128 254 C 132 228 148 200 172 180 C 178 175 186 173 189 178 C 192 183 188 190 181 196 C 167 212 155 232 150 254 Z" fill="%236938ef" stroke="url(%23dragon-grad)" stroke-width="1.5"/> <path d="M 164 202 C 175 191 188 190 196 196 C 190 203 179 206 171 212 Z" fill="%23875bf7"/> <path d="M 76 342 C 65 339 55 328 52 314 C 49 299 57 287 70 284 C 80 282 90 286 97 282 C 104 278 108 268 118 265 C 131 262 144 270 148 285 C 152 300 148 320 137 334 C 121 355 96 355 76 342 Z" fill="%23f4f7fb" stroke="url(%23dragon-grad)" stroke-width="3.5" stroke-linejoin="round"/> <path d="M 52 311 C 41 305 38 290 46 280 C 54 270 69 272 73 285 C 76 295 69 308 57 308 C 51 308 48 302 51 296 C 53 292 58 292 60 296" fill="%23ede9fe" stroke="url(%23dragon-grad)" stroke-width="3" stroke-linecap="round"/> <line x1="58" y1="321" x2="107" y2="331" stroke="url(%23dragon-grad)" stroke-width="3" stroke-linecap="round"/> <path d="M 65 321 L 69 333 L 73 323 Z" fill="url(%23dragon-grad)"/> <path d="M 74 323 L 78 335 L 82 325 Z" fill="url(%23dragon-grad)"/> <path d="M 83 325 L 87 337 L 91 327 Z" fill="url(%23dragon-grad)"/> <path d="M 92 327 L 96 338 L 100 329 Z" fill="url(%23dragon-grad)"/> <path d="M 72 337 C 67 348 70 361 80 365 C 91 369 100 362 104 352 C 107 344 104 337 97 335" fill="%23e2e8f0" stroke="url(%23dragon-grad)" stroke-width="3" stroke-linecap="round"/> <path d="M 70 296 C 50 306 36 326 34 348 C 31 374 50 397 74 400 C 95 403 112 390 113 374 C 115 361 104 352 94 355 C 85 358 83 368 91 376" fill="none" stroke="url(%23dragon-grad)" stroke-width="3.5" stroke-linecap="round"/> <path d="M 96 272 C 104 261 119 259 130 265 C 137 270 140 278 136 285 C 131 291 122 289 118 283 C 114 277 104 276 100 281" fill="%23ede9fe" stroke="url(%23dragon-grad)" stroke-width="2.5" stroke-linecap="round"/> <ellipse cx="115" cy="290" rx="14" ry="12" fill="%23ffffff" stroke="url(%23dragon-grad)" stroke-width="3"/> <circle cx="115" cy="290" r="7.5" fill="%236938ef"/> <circle cx="113" cy="288" r="2.8" fill="%23ffffff"/> </g> <g id="clouds" stroke="url(%23dragon-grad)" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0.5"> <path d="M 35 448 C 24 436 25 420 38 415 C 50 410 62 420 62 432 C 72 428 84 434 84 446"/> <path d="M 444 128 C 434 112 438 96 451 93 C 464 90 474 102 470 116 C 482 118 490 132 484 146"/> </g> </g> </g> </svg>');background-size:cover;background-position:center;background-repeat:no-repeat;color:#0f172a;user-select:none;overflow:hidden;}.loader{width:100%;max-width:320px;padding:0 24px;display:flex;flex-direction:column;align-items:center;justify-content:center;}.progress-track{width:100%;height:4px;background:rgba(105,56,239,0.12);border-radius:9999px;overflow:hidden;position:relative;box-shadow:0 1px 2px rgba(0,0,0,0.05);}.progress-bar{position:absolute;top:0;bottom:0;left:0;width:40%;background:linear-gradient(90deg,#6938ef,#9061f9);border-radius:9999px;animation:horizontal-loading 1.4s infinite ease-in-out;}@keyframes horizontal-loading{0%{left:-40%;}100%{left:100%;}}</style></head><body oncontextmenu="return false;"><div class="loader"><div class="progress-track"><div class="progress-bar"></div></div></div></body></html>`)}`;

function isAbortedNavigation(error) {
  if (!error) return false;
  const message = error.message || String(error);
  return (
    message.includes("ERR_ABORTED") ||
    message.includes("-3") ||
    message.includes("navigation was aborted")
  );
}

function isTransientServerConnectionError(errorCode, errorDescription = "") {
  try {
    const errorString = String(errorDescription || "");
    const numericCode = typeof errorCode === "number" ? errorCode : parseInt(errorCode, 10);
    return (
      numericCode === -102 ||
      numericCode === -101 ||
      numericCode === -100 ||
      numericCode === -104 ||
      numericCode === -105 ||
      numericCode === -106 ||
      numericCode === -118 ||
      numericCode === -7 ||
      numericCode === -324 ||
      numericCode === -21 ||
      errorString.includes("ERR_CONNECTION_REFUSED") ||
      errorString.includes("ERR_CONNECTION_RESET") ||
      errorString.includes("ERR_CONNECTION_CLOSED") ||
      errorString.includes("ERR_CONNECTION_FAILED") ||
      errorString.includes("ERR_CONNECTION_TIMED_OUT") ||
      errorString.includes("ERR_TIMED_OUT")
    );
  } catch (error) {
    displayElectronError("Transient Connection Error Check", error);
    return false;
  }
}

async function executeServerPollLoop(activeWindow, targetUrl, pollIntervalMs = 400) {
  try {
    while (
      activeWindow &&
      typeof activeWindow.isDestroyed === "function" &&
      !activeWindow.isDestroyed()
    ) {
      const isServerRunning = await checkServerReady(targetUrl);
      if (isServerRunning) {
        console.log(
          `[Notes Electron] Next.js server on ${targetUrl} run successfully. Transitioning from loading screen...`
        );
        activeWindow.__notes_is_polling_server__ = false;
        if (
          activeWindow &&
          typeof activeWindow.isDestroyed === "function" &&
          !activeWindow.isDestroyed() &&
          typeof activeWindow.loadURL === "function"
        ) {
          activeWindow.loadURL(targetUrl).catch((navigationError) => {
            if (!isAbortedNavigation(navigationError)) {
              console.warn("[Notes Electron] Target URL load deferred:", navigationError);
            }
          });
        }
        return true;
      }
      await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
    }
    return false;
  } catch (error) {
    if (activeWindow) {
      activeWindow.__notes_is_polling_server__ = false;
    }
    displayElectronError("Execute Server Poll Loop Error", error);
    return false;
  }
}

function keepLoadingScreenUntilServerReady(
  targetWindow,
  targetUrl = APP_URL,
  splashHtml = DEFAULT_SPLASH_HTML_CONTENT
) {
  try {
    const activeWindow = targetWindow || mainWindow;
    if (
      !activeWindow ||
      (typeof activeWindow.isDestroyed === "function" && activeWindow.isDestroyed())
    ) {
      return;
    }

    if (activeWindow.__notes_is_polling_server__) {
      return;
    }
    activeWindow.__notes_is_polling_server__ = true;

    if (typeof activeWindow.loadURL === "function") {
      const currentUrl =
        activeWindow.webContents && typeof activeWindow.webContents.getURL === "function"
          ? activeWindow.webContents.getURL()
          : "";
      if (!currentUrl || !currentUrl.startsWith("data:text/html")) {
        activeWindow.loadURL(splashHtml).catch(() => {});
      }
    }

    void executeServerPollLoop(activeWindow, targetUrl, 400);
  } catch (error) {
    displayElectronError("Keep Loading Screen Error", error);
  }
}

/**
 * Create main application window
 */
function createMainWindow(explicitUrl = null) {
  try {
    if (!BrowserWindow) {
      return null;
    }

    const windowOptions = {
      width: 1280,
      height: 840,
      minWidth: 800,
      minHeight: 600,
      title: APP_TITLE,
      titleBarStyle: "hidden",
      titleBarOverlay: false,
      autoHideMenuBar: true,
      backgroundColor: "#ffffff",
      show: true,
      webPreferences: {
        preload: path.join(__dirname, "preload.cjs"),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
      },
    };

    mainWindow = new BrowserWindow(windowOptions);

    if (typeof mainWindow.setMenuBarVisibility === "function") {
      mainWindow.setMenuBarVisibility(false);
    }

    mainWindow.once("ready-to-show", () => {
      if (mainWindow) {
        mainWindow.show();
        if (pendingFileToOpen) {
          mainWindow.webContents.send("file:open-external", pendingFileToOpen);
        }
      }
    });

    mainWindow.on("maximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("window:maximized-change", true);
      }
    });

    mainWindow.on("unmaximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("window:maximized-change", false);
      }
    });

    mainWindow.on("closed", () => {
      mainWindow = null;
    });

    if (mainWindow.webContents && typeof mainWindow.webContents.on === "function") {
      mainWindow.webContents.on(
        "did-fail-load",
        (_event, errorCode, errorDescription, _validatedURL, isMainFrame) => {
          if (typeof isMainFrame === "boolean" && !isMainFrame) {
            return;
          }
          if (errorCode === -3) {
            return;
          }
          if (isTransientServerConnectionError(errorCode, errorDescription)) {
            console.warn(
              `[Notes Electron] Next.js dev server compiling or starting (${errorCode}: ${errorDescription}). Keeping loading screen active...`
            );
            if (
              mainWindow &&
              !mainWindow.isDestroyed() &&
              typeof mainWindow.loadURL === "function"
            ) {
              mainWindow.loadURL(DEFAULT_SPLASH_HTML_CONTENT).catch(() => {});
            }
            keepLoadingScreenUntilServerReady(mainWindow, APP_URL, DEFAULT_SPLASH_HTML_CONTENT);
          } else {
            displayElectronError(
              "Desktop Window Load Error",
              new Error(`Page load failed with code ${errorCode}: ${errorDescription}`)
            );
          }
        }
      );
    }

    if (explicitUrl) {
      mainWindow.loadURL(explicitUrl).catch((navigationError) => {
        if (!isAbortedNavigation(navigationError)) {
          keepLoadingScreenUntilServerReady(mainWindow, APP_URL, DEFAULT_SPLASH_HTML_CONTENT);
        }
      });
    } else {
      keepLoadingScreenUntilServerReady(mainWindow, APP_URL, DEFAULT_SPLASH_HTML_CONTENT);
    }

    return mainWindow;
  } catch (windowCreationError) {
    displayElectronError("Window Creation Error", windowCreationError);
    return null;
  }
}

let internalNextServerProcess = null;

/**
 * Check whether the local Next.js server is responsive on the target URL
 */
function checkServerReady(targetUrl = APP_URL) {
  try {
    return new Promise((resolve) => {
      const request = http.get(targetUrl, (response) => {
        resolve(true);
        response.resume();
      });

      request.on("error", () => {
        if (targetUrl.includes("localhost:")) {
          const fallbackUrl = targetUrl.replace("localhost:", "127.0.0.1:");
          const fallbackRequest = http.get(fallbackUrl, (fallbackResponse) => {
            resolve(true);
            fallbackResponse.resume();
          });
          fallbackRequest.on("error", () => resolve(false));
          fallbackRequest.setTimeout(800, () => {
            fallbackRequest.destroy();
            resolve(false);
          });
        } else {
          resolve(false);
        }
      });

      request.setTimeout(800, () => {
        request.destroy();
        resolve(false);
      });
    });
  } catch (checkError) {
    return Promise.resolve(false);
  }
}

/**
 * Dual-start orchestrator: ensure Next.js server is running before loading view
 */
async function ensureLocalServerRunning(targetUrl = APP_URL, maximumWaitAttempts = 60) {
  try {
    const isAlreadyRunning = await checkServerReady(targetUrl);
    if (isAlreadyRunning) {
      console.log(`[Notes Electron] Server is already active on ${targetUrl}`);
      return true;
    }

    const { spawn } = require("node:child_process");
    const os = require("node:os");
    const appDirectory = path.resolve(__dirname, "..");
    const appBaseName = path.basename(appDirectory);
    const candidateServerPaths = [
      path.join(appDirectory, "server.js"),
      path.join(appDirectory, ".next", "standalone", "packages", appBaseName, "server.js"),
      path.join(appDirectory, ".next", "standalone", "server.js"),
      path.join(os.homedir(), ".2tek", "Applications", "notes", "server.js"),
      path.join(os.homedir(), ".2tek", "Applications", "notes", "packages", appBaseName, "server.js"),
    ];
    let resolvedServerJsPath = null;
    for (const candidate of candidateServerPaths) {
      if (fileSystem.existsSync(candidate)) {
        resolvedServerJsPath = candidate;
        break;
      }
    }
    const serverJsPath = resolvedServerJsPath || path.join(appDirectory, "server.js");
    const isWindows = process.platform === "win32";

    console.log(`[Notes Electron] Dual-starting Next.js server on port ${TARGET_PORT}...`);

    if (resolvedServerJsPath) {
      internalNextServerProcess = spawn(process.execPath, [resolvedServerJsPath], {
        cwd: appDirectory,
        stdio: "inherit",
        env: {
          ...process.env,
          PORT: String(TARGET_PORT),
          HOSTNAME: "0.0.0.0",
          NODE_ENV: "production",
        },
      });
    } else {
      const npmCommand = isWindows ? "npm.cmd" : "npm";
      internalNextServerProcess = spawn(npmCommand, ["run", "dev"], {
        cwd: appDirectory,
        stdio: "inherit",
        env: {
          ...process.env,
          PORT: String(TARGET_PORT),
          NOTES_PORT: String(TARGET_PORT),
        },
      });
    }

    if (internalNextServerProcess) {
      internalNextServerProcess.on("error", (spawnError) => {
        console.error(`[Notes Electron] Failed to spawn Next.js server:`, spawnError);
      });
    }

    for (let attempt = 1; attempt <= maximumWaitAttempts; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      const ready = await checkServerReady(targetUrl);
      if (ready) {
        console.log(`[Notes Electron] Next.js server ready at ${targetUrl} (attempt ${attempt})`);
        return true;
      }
    }

    console.warn(`[Notes Electron] Server wait timed out, proceeding to load view`);
    return false;
  } catch (launchError) {
    displayElectronError("Next.js Server Launch Error", launchError);
    return false;
  }
}

/**
 * Cleanly terminates the spawned Next.js server process
 */
function terminateInternalServer() {
  try {
    if (internalNextServerProcess) {
      console.log(`[Notes Electron] Terminating internal Next.js server process (pid: ${internalNextServerProcess.pid})...`);
      try {
        internalNextServerProcess.kill("SIGTERM");
      } catch {
        // Ignore kill error
      }
      internalNextServerProcess = null;
    }
  } catch (termError) {
    // Ignore termination error
  }
}

// Single-instance lock
if (app && typeof app.requestSingleInstanceLock === "function") {
  const gotSingleInstanceLock = app.requestSingleInstanceLock();
  if (!gotSingleInstanceLock) {
    app.quit();
  } else {
    app.on("second-instance", (_event, commandLine) => {
      if (mainWindow) {
        if (mainWindow.isMinimized()) {
          mainWindow.restore();
        }
        mainWindow.focus();

        if (commandLine && commandLine.length > 2) {
          for (let argIdx = 2; argIdx < commandLine.length; argIdx += 1) {
            const candidatePath = commandLine[argIdx];
            if (
              candidatePath &&
              !candidatePath.startsWith("-") &&
              fileSystem.existsSync(candidatePath)
            ) {
              mainWindow.webContents.send("file:open-external", path.resolve(candidatePath));
              break;
            }
          }
        }
      }
    });
  }
}

if (app && typeof app.whenReady === "function") {
  app.whenReady().then(async () => {
    const isServerAlreadyListening = await checkServerReady(APP_URL);
    createMainWindow(isServerAlreadyListening ? APP_URL : null);

    if (!isServerAlreadyListening) {
      void ensureLocalServerRunning(APP_URL);
    }

    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow();
      }
    });
  });

  app.on("window-all-closed", () => {
    terminateInternalServer();
    if (process.platform !== "darwin") {
      app.quit();
    }
  });

  app.on("before-quit", () => {
    terminateInternalServer();
  });

  app.on("will-quit", () => {
    terminateInternalServer();
  });

  process.on("exit", () => {
    terminateInternalServer();
  });
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    createMainWindow,
    resolvePortFromEnv,
    checkServerReady,
    ensureLocalServerRunning,
    terminateInternalServer,
    displayElectronError,
    DEFAULT_SPLASH_HTML_CONTENT,
    isTransientServerConnectionError,
    keepLoadingScreenUntilServerReady,
    executeServerPollLoop,
  };
}
