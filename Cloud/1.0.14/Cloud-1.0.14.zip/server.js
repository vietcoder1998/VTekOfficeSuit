// 2-TEK Standalone Next.js Server Wrapper
const path = require("node:path");
const fs = require("node:fs");

process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3018";
process.env.HOSTNAME = process.env.HOSTNAME || "0.0.0.0";

const candidateServerPaths = [
  path.join(__dirname, "server.js"),
  path.join(__dirname, "packages", "Cloud", "server.js"),
  path.join(__dirname, ".next", "standalone", "server.js"),
];

let standaloneExecuted = false;
for (const candidatePath of candidateServerPaths) {
  if (candidatePath !== __filename && fs.existsSync(candidatePath)) {
    require(candidatePath);
    standaloneExecuted = true;
    break;
  }
}

if (!standaloneExecuted) {
  const http = require("node:http");
  const port = parseInt(process.env.PORT, 10);
  const hostname = process.env.HOSTNAME;
  const server = http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<!DOCTYPE html><html><head><title>Cloud Storage</title></head><body><h1>Cloud Storage</h1><p>Cloud storage manager, file permissions, and cloud resource viewer.</p></body></html>`);
  });
  server.listen(port, hostname, () => {
    console.log(`> Cloud Storage standalone running on http://${hostname}:${port}`);
  });
}
