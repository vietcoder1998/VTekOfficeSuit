// 2-TEK Standalone Next.js Server Wrapper
const path = require("node:path");
const fs = require("node:fs");

process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3021";
process.env.HOSTNAME = process.env.HOSTNAME || "0.0.0.0";

const candidateServerPaths = [
  path.join(__dirname, "server.js"),
  path.join(__dirname, "packages", "AIAssistant", "server.js"),
  path.join(__dirname, ".next", "standalone", "packages", "AIAssistant", "server.js"),
  path.join(__dirname, ".next", "standalone", "server.js"),
  path.join(__dirname, "server-standalone.js"),
  "/home/tranduyviet/Projects/2tek-office-packs/packages/AIAssistant/.next/standalone/packages/AIAssistant/server.js",
  "/home/tranduyviet/Projects/2tek-office-packs/packages/AIAssistant/.next/standalone/server.js",
];

let standaloneExecuted = false;
for (const candidatePath of candidateServerPaths) {
  if (candidatePath && candidatePath !== __filename && fs.existsSync(candidatePath)) {
    try {
      require(candidatePath);
      standaloneExecuted = true;
      break;
    } catch (candidateError) {
      console.warn(
        "> Standalone candidate failed to load (" + candidatePath + "):",
        candidateError && candidateError.message ? candidateError.message : candidateError
      );
    }
  }
}

if (!standaloneExecuted) {
  const http = require("node:http");
  const port = parseInt(process.env.PORT, 10);
  const hostname = process.env.HOSTNAME;
  const server = http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<!DOCTYPE html><html><head><title>AI Assistant Platform</title></head><body><h1>AI Assistant Platform</h1><p>2-TEK Autonomous AI Assistant and workspace Copilot.</p></body></html>`);
  });
  server.listen(port, hostname, () => {
    console.log(`> AI Assistant Platform standalone running on http://${hostname}:${port}`);
  });
}
