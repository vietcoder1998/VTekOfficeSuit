@echo off
rem 2-TEK Dual-Start Launcher: Next.js Standalone + Electron
cd /d "%~dp0"
if exist electron\runner.cjs (
  node electron\runner.cjs %*
) else if exist electron\main.cjs (
  npx electron electron\main.cjs %*
) else (
  node server.js %*
)
