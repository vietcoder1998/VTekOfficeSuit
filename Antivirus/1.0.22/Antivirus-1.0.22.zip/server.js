// 2-TEK Standalone Next.js Server Wrapper
const path = require("node:path");
const fs = require("node:fs");

process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3039";
process.env.HOSTNAME = process.env.HOSTNAME || "0.0.0.0";

const candidateServerPaths = [
  path.join(__dirname, "server.js"),
  path.join(__dirname, "packages", "Antivirus", "server.js"),
  path.join(__dirname, ".next", "standalone", "packages", "Antivirus", "server.js"),
  path.join(__dirname, ".next", "standalone", "server.js"),
  path.join(__dirname, "server-standalone.js"),
];

let standaloneExecuted = false;
for (const candidatePath of candidateServerPaths) {
  if (candidatePath !== __filename && fs.existsSync(candidatePath)) {
    require(candidatePath);
    standaloneExecuted = true;
    break;
  }
}

if (!standaloneExecuted) {
  const http = require("node:http");
  const port = parseInt(process.env.PORT, 10);
  const hostname = process.env.HOSTNAME;
  const server = http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<!DOCTYPE html><html><head><title>Antivirus & System Health</title></head><body><h1>Antivirus & System Health</h1><p>Desktop security scanner, AST malware detector, and real-time system health & process monitor.</p></body></html>`);
  });
  server.listen(port, hostname, () => {
    console.log(`> Antivirus & System Health standalone running on http://${hostname}:${port}`);
  });
}
