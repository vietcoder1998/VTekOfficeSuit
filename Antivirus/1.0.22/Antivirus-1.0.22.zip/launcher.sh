#!/bin/bash
# 2-TEK Dual-Start Launcher: Next.js Standalone + Electron
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
if [ -f "electron/runner.cjs" ]; then
  exec node electron/runner.cjs "$@"
elif [ -f "electron/main.cjs" ]; then
  exec npx electron electron/main.cjs "$@"
else
  exec node server.js "$@"
fi
