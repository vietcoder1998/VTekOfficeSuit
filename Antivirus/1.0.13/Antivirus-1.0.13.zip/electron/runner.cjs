/**
 * Packages/Antivirus/electron/runner.cjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Antivirus & System Health Studio — Electron Development Orchestrator
 *
 * Checks/starts the Next.js dev server on port 3039, waits for HTTP readiness,
 * and launches the Electron desktop application.
 * Conforms to: Electron Single Try-Catch & Mandatory Error Display Rule
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { spawn } = require("node:child_process");
const http = require("node:http");
const path = require("node:path");
const fileSystem = require("node:fs");

function resolveAntivirusPortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsedPort = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsedPort) && parsedPort > 0) {
          return parsedPort;
        }
      }
      if (process.env.ANTIVIRUS_PORT) {
        const parsedAntivirusPort = parseInt(process.env.ANTIVIRUS_PORT, 10);
        if (!Number.isNaN(parsedAntivirusPort) && parsedAntivirusPort > 0) {
          return parsedAntivirusPort;
        }
      }
    }

    const antivirusRootDirectory = path.resolve(__dirname, "..");
    const candidateEnvironmentFiles = [
      path.join(antivirusRootDirectory, ".env"),
      path.join(antivirusRootDirectory, ".env.local"),
      path.join(antivirusRootDirectory, ".env.development"),
    ];

    for (const candidateEnvironmentFilePath of candidateEnvironmentFiles) {
      if (fileSystem.existsSync(candidateEnvironmentFilePath)) {
        const fileContentString = fileSystem.readFileSync(candidateEnvironmentFilePath, "utf8");
        const fileLines = fileContentString.split(/\r?\n/);
        for (const singleLine of fileLines) {
          const trimmedLine = singleLine.trim();
          if (trimmedLine.startsWith("#") || !trimmedLine.includes("=")) {
            continue;
          }
          const separatorIndex = trimmedLine.indexOf("=");
          const variableKey = trimmedLine.slice(0, separatorIndex).trim();
          if (variableKey === "PORT" || variableKey === "ANTIVIRUS_PORT") {
            const rawVariableValue = trimmedLine.slice(separatorIndex + 1).trim();
            const cleanVariableValue = rawVariableValue.replace(/^["']|["']$/g, "");
            const parsedPort = parseInt(cleanVariableValue, 10);
            if (!Number.isNaN(parsedPort) && parsedPort > 0) {
              return parsedPort;
            }
          }
        }
      }
    }
  } catch (resolvePortError) {
    console.error("[Antivirus Runner Error] Failed resolving port from env:", resolvePortError);
  }

  return 3039;
}

const ANTIVIRUS_TARGET_PORT = resolveAntivirusPortFromEnv();
const ANTIVIRUS_DEV_SERVER_URL = `http://localhost:${ANTIVIRUS_TARGET_PORT}`;
const MAXIMUM_POLL_ATTEMPTS = 120;
const POLL_INTERVAL_MILLISECONDS = 500;

let nextServerProcess = null;
let electronChildProcess = null;

function checkServerReady(targetUrl = ANTIVIRUS_DEV_SERVER_URL) {
  try {
    return new Promise((resolve) => {
      const request = http.get(targetUrl, (response) => {
        resolve(true);
        response.resume();
      });

      request.on("error", () => {
        if (targetUrl.includes("localhost:")) {
          const fallbackUrl = targetUrl.replace("localhost:", "127.0.0.1:");
          const fallbackRequest = http.get(fallbackUrl, (fallbackResponse) => {
            resolve(true);
            fallbackResponse.resume();
          });
          fallbackRequest.on("error", () => resolve(false));
          fallbackRequest.setTimeout(800, () => {
            fallbackRequest.destroy();
            resolve(false);
          });
        } else {
          resolve(false);
        }
      });

      request.setTimeout(800, () => {
        request.destroy();
        resolve(false);
      });
    });
  } catch (checkServerError) {
    console.error("[Antivirus Runner Error] checkServerReady exception:", checkServerError);
    return Promise.resolve(false);
  }
}

async function waitForServerReadiness(targetUrl = ANTIVIRUS_DEV_SERVER_URL) {
  console.log(`[Antivirus Runner] Checking Next.js dev server readiness at ${targetUrl}...`);
  for (let pollAttempt = 1; pollAttempt <= MAXIMUM_POLL_ATTEMPTS; pollAttempt += 1) {
    const isServerReady = await checkServerReady(targetUrl);
    if (isServerReady) {
      console.log(`[Antivirus Runner] Dev server is ready at ${targetUrl} (attempt ${pollAttempt}).`);
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MILLISECONDS));
  }
  console.warn(`[Antivirus Runner] Dev server was not ready after ${MAXIMUM_POLL_ATTEMPTS} attempts. Proceeding with launch...`);
  return false;
}

function startNextDevServer() {
  try {
    const projectRootDirectory = path.resolve(__dirname, "..");
    console.log(`[Antivirus Runner] Spawning Next.js development server on port ${ANTIVIRUS_TARGET_PORT}...`);

    nextServerProcess = spawn(
      "npx",
      ["next", "dev", "-p", String(ANTIVIRUS_TARGET_PORT)],
      {
        cwd: projectRootDirectory,
        stdio: "inherit",
        shell: true,
        env: {
          ...process.env,
          PORT: String(ANTIVIRUS_TARGET_PORT),
          ANTIVIRUS_PORT: String(ANTIVIRUS_TARGET_PORT),
        },
      }
    );

    nextServerProcess.on("error", (spawnError) => {
      console.error("[Antivirus Runner Error] Failed to spawn Next.js dev server:", spawnError);
    });

    nextServerProcess.on("exit", (exitCode, terminationSignal) => {
      console.log(`[Antivirus Runner] Next.js dev server exited with code ${exitCode}, signal ${terminationSignal}`);
    });
  } catch (startNextError) {
    console.error("[Antivirus Runner Error] startNextDevServer exception:", startNextError);
  }
}

function launchElectronApp() {
  try {
    const mainProcessScriptPath = path.join(__dirname, "main.cjs");
    const projectRootDirectory = path.resolve(__dirname, "..");

    console.log("[Antivirus Runner] Launching Electron desktop window...");

    const electronBinaryPath = require("electron");

    electronChildProcess = spawn(
      electronBinaryPath,
      [mainProcessScriptPath, ...process.argv.slice(2)],
      {
        cwd: projectRootDirectory,
        stdio: "inherit",
        env: {
          ...process.env,
          PORT: String(ANTIVIRUS_TARGET_PORT),
          ANTIVIRUS_PORT: String(ANTIVIRUS_TARGET_PORT),
        },
      }
    );

    electronChildProcess.on("error", (launchError) => {
      console.error("[Antivirus Runner Error] Failed to launch Electron process:", launchError);
    });

    electronChildProcess.on("exit", (childExitCode) => {
      console.log(`[Antivirus Runner] Electron window closed with exit code ${childExitCode}.`);
      cleanupProcesses();
      process.exit(childExitCode || 0);
    });
  } catch (launchException) {
    console.error("[Antivirus Runner Error] launchElectronApp exception:", launchException);
    cleanupProcesses();
    process.exit(1);
  }
}

function cleanupProcesses() {
  try {
    if (nextServerProcess && !nextServerProcess.killed) {
      console.log("[Antivirus Runner] Terminating Next.js child process...");
      nextServerProcess.kill("SIGTERM");
      nextServerProcess = null;
    }
    if (electronChildProcess && !electronChildProcess.killed) {
      electronChildProcess.kill("SIGTERM");
      electronChildProcess = null;
    }
  } catch (cleanupError) {
    console.error("[Antivirus Runner Error] cleanupProcesses exception:", cleanupError);
  }
}

process.on("SIGINT", () => {
  cleanupProcesses();
  process.exit(0);
});

process.on("SIGTERM", () => {
  cleanupProcesses();
  process.exit(0);
});

async function main() {
  try {
    const alreadyRunning = await checkServerReady();
    if (!alreadyRunning) {
      startNextDevServer();
    } else {
      console.log(`[Antivirus Runner] Next.js server already running at ${ANTIVIRUS_DEV_SERVER_URL}.`);
    }

    await waitForServerReadiness();
    launchElectronApp();
  } catch (mainError) {
    console.error("[Antivirus Runner Error] Orchestrator main error:", mainError);
    cleanupProcesses();
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  checkServerReady,
  resolveAntivirusPortFromEnv,
};
