/**
 * Packages/Antivirus/electron/main.cjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Antivirus & System Health Studio — Electron Main Process
 *
 * Provides desktop window lifecycle management, titlebar controls,
 * native file & folder dialogs, system telemetry, and IPC channels for
 * desktop security scanning and real-time health monitoring.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const path = require("node:path");
const http = require("node:http");
const fileSystem = require("node:fs");
const os = require("node:os");

function loadElectronModule() {
  try {
    if (typeof global !== "undefined" && global.__antivirus_electron_mock__) {
      return global.__antivirus_electron_mock__;
    }
    const loadedModule = require("electron");
    if (typeof loadedModule === "object" && loadedModule !== null) {
      return loadedModule;
    }
    return {};
  } catch (loadError) {
    console.warn(
      "[Antivirus Electron] Electron module unavailable in current environment:",
      loadError && loadError.message ? loadError.message : loadError
    );
    return {};
  }
}

const electronModule = loadElectronModule();
const { app, BrowserWindow, ipcMain, dialog } = electronModule;

/**
 * Native error dialog helper conforming to single try-catch pattern
 */
function displayElectronError(title = "2-TEK Antivirus Error", error = null, detail = "") {
  try {
    const errorMessage =
      error && error.message
        ? error.message
        : typeof error === "string"
        ? error
        : "An unexpected error occurred.";
    const formattedDetail = detail || (error && error.stack ? error.stack : "");

    console.error(
      `[Antivirus Electron Error] ${title}: ${errorMessage}`,
      formattedDetail ? `\nDetail: ${formattedDetail}` : ""
    );

    const activeDialog =
      (electronModule && electronModule.dialog) ||
      dialog ||
      (typeof global !== "undefined" && global.__antivirus_electron_dialog__);

    if (activeDialog && typeof activeDialog.showErrorBox === "function") {
      activeDialog.showErrorBox(
        title,
        formattedDetail ? `${errorMessage}\n\n${formattedDetail}` : errorMessage
      );
      return true;
    }

    if (activeDialog && typeof activeDialog.showMessageBoxSync === "function") {
      activeDialog.showMessageBoxSync({
        type: "error",
        title,
        message: title,
        detail: formattedDetail ? `${errorMessage}\n\n${formattedDetail}` : errorMessage,
        buttons: ["OK"],
        noLink: true,
      });
      return true;
    }

    return false;
  } catch (displayException) {
    console.error("[Antivirus Electron Error] Failed to display native error dialog:", displayException);
    return false;
  }
}

/**
 * Configure application metadata
 */
function configureAppMetadata() {
  try {
    if (app && typeof app.setName === "function") {
      app.setName("2-tek-antivirus");
    }
    if (app && typeof app.setAppUserModelId === "function") {
      app.setAppUserModelId("com.vtek.antivirus");
    }
  } catch (metadataError) {
    displayElectronError("Configure Metadata Error", metadataError);
  }
}

configureAppMetadata();

/**
 * Resolve target port (default: 3039)
 */
function resolveAntivirusPortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsedPort = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsedPort) && parsedPort > 0) {
          return parsedPort;
        }
      }
      if (process.env.ANTIVIRUS_PORT) {
        const parsedAntivirusPort = parseInt(process.env.ANTIVIRUS_PORT, 10);
        if (!Number.isNaN(parsedAntivirusPort) && parsedAntivirusPort > 0) {
          return parsedAntivirusPort;
        }
      }
    }

    const antivirusRootDirectory = path.resolve(__dirname, "..");
    const candidateEnvironmentFiles = [
      path.join(antivirusRootDirectory, ".env"),
      path.join(antivirusRootDirectory, ".env.local"),
      path.join(antivirusRootDirectory, ".env.development"),
    ];

    for (const candidateFilePath of candidateEnvironmentFiles) {
      if (fileSystem.existsSync(candidateFilePath)) {
        const fileContentString = fileSystem.readFileSync(candidateFilePath, "utf8");
        const fileLines = fileContentString.split(/\r?\n/);
        for (const singleLine of fileLines) {
          const trimmedLine = singleLine.trim();
          if (trimmedLine.startsWith("#") || !trimmedLine.includes("=")) {
            continue;
          }
          const separatorIndex = trimmedLine.indexOf("=");
          const variableKey = trimmedLine.slice(0, separatorIndex).trim();
          if (variableKey === "PORT" || variableKey === "ANTIVIRUS_PORT") {
            const rawVariableValue = trimmedLine.slice(separatorIndex + 1).trim();
            const cleanVariableValue = rawVariableValue.replace(/^["']|["']$/g, "");
            const parsedPort = parseInt(cleanVariableValue, 10);
            if (!Number.isNaN(parsedPort) && parsedPort > 0) {
              return parsedPort;
            }
          }
        }
      }
    }
  } catch (portError) {
    console.error("[Antivirus Electron Error] Failed resolving port from env:", portError);
  }

  return 3039;
}

const ANTIVIRUS_PORT = resolveAntivirusPortFromEnv();
const ANTIVIRUS_APP_URL = `http://localhost:${ANTIVIRUS_PORT}`;

let mainWindow = null;

const DEFAULT_CODE_EXTENSIONS = [
  ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json",
  ".yml", ".yaml", ".html", ".css", ".sh", ".bash", ".py",
  ".env", ".md", ".txt", ".toml", ".sql", ".xml"
];

const DEFAULT_IGNORED_DIRS = [
  "node_modules", ".git", ".next", "dist", "build",
  ".turbo", ".cache", "coverage", ".venv", "venv", "__pycache__"
];

/**
 * Traverses a real local directory and reads real code files
 */
async function readRealFilesRecursively(targetDirPath, maxFiles = 500, maxDepth = 8) {
  const collected = [];
  const resolvedRoot = path.resolve(targetDirPath);

  async function walk(currDir, depth) {
    if (depth > maxDepth || collected.length >= maxFiles) return;
    let entries = [];
    try {
      entries = await fileSystem.promises.readdir(currDir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const ent of entries) {
      if (collected.length >= maxFiles) break;
      const fullPath = path.join(currDir, ent.name);
      if (ent.isDirectory()) {
        const lowerName = ent.name.toLowerCase();
        if (DEFAULT_IGNORED_DIRS.includes(lowerName)) continue;
        await walk(fullPath, depth + 1);
      } else if (ent.isFile()) {
        const ext = path.extname(ent.name).toLowerCase();
        const base = path.basename(ent.name).toLowerCase();
        if (!DEFAULT_CODE_EXTENSIONS.includes(ext) && !base.startsWith(".env") && base !== "dockerfile") {
          continue;
        }
        try {
          const st = await fileSystem.promises.stat(fullPath);
          if (st.size > 5 * 1024 * 1024) continue; // max 5MB
          const content = await fileSystem.promises.readFile(fullPath, "utf8");
          const relPath = path.relative(resolvedRoot, fullPath);
          collected.push({
            filename: relPath,
            content,
            fullPath,
            size: st.size,
          });
        } catch {
          continue;
        }
      }
    }
  }

  await walk(resolvedRoot, 1);
  return collected;
}

/**
 * Register IPC handlers for window controls, native dialogs, and system telemetry
 */
function registerIpcHandlers() {
  try {
    if (!ipcMain || typeof ipcMain.handle !== "function") {
      return;
    }

    // Window controls
    ipcMain.handle("window:minimize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.minimize();
        return true;
      }
      return false;
    });

    ipcMain.handle("window:maximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        if (mainWindow.isMaximized()) {
          mainWindow.unmaximize();
        } else {
          mainWindow.maximize();
        }
        return true;
      }
      return false;
    });

    ipcMain.handle("window:close", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.close();
        return true;
      }
      return false;
    });

    ipcMain.handle("window:is-maximized", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        return mainWindow.isMaximized();
      }
      return false;
    });

    // Native file and folder dialogs
    ipcMain.handle("folder:select-dialog", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showOpenDialog !== "function") {
          return { canceled: true, filePaths: [] };
        }
        const openResult = await dialog.showOpenDialog(mainWindow, {
          title: options.title || "Chọn thư mục để quét bảo mật (Select Folder to Scan)",
          defaultPath: options.defaultPath,
          buttonLabel: options.buttonLabel || "Chọn thư mục (Select Folder)",
          properties: ["openDirectory"],
        });
        if (openResult.canceled || !openResult.filePaths || openResult.filePaths.length === 0) {
          return { canceled: true, filePaths: [] };
        }
        return { canceled: false, filePaths: openResult.filePaths };
      } catch (folderDialogError) {
        displayElectronError("Open Folder Dialog Error", folderDialogError);
        return { canceled: true, filePaths: [] };
      }
    });

    ipcMain.handle("file:open-dialog", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showOpenDialog !== "function") {
          return { canceled: true, filePaths: [] };
        }
        const openResult = await dialog.showOpenDialog(mainWindow, {
          title: options.title || "Chọn tệp mã nguồn để quét (Select File to Scan)",
          defaultPath: options.defaultPath,
          buttonLabel: options.buttonLabel || "Mở tệp (Open)",
          properties: options.properties || ["openFile", "multiSelections"],
          filters: options.filters || [
            {
              name: "Mã nguồn & Cấu hình (Code & Configs)",
              extensions: ["ts", "tsx", "js", "jsx", "mjs", "json", "yml", "yaml", "md", "html", "sh", "py", "sql", "env"],
            },
            { name: "Tất cả tệp (All Files)", extensions: ["*"] },
          ],
        });

        if (openResult.canceled || !openResult.filePaths || openResult.filePaths.length === 0) {
          return { canceled: true, filePaths: [] };
        }
        return { canceled: false, filePaths: openResult.filePaths };
      } catch (fileDialogError) {
        displayElectronError("Open File Dialog Error", fileDialogError);
        return { canceled: true, filePaths: [] };
      }
    });

    // Read real files recursively from a directory path on real computer
    ipcMain.handle("folder:read-files", async (_event, { targetFolderPath, options = {} }) => {
      try {
        if (!targetFolderPath || typeof targetFolderPath !== "string") {
          return { success: false, error: "Invalid target folder path" };
        }
        const collectedFiles = await readRealFilesRecursively(targetFolderPath, options.maxFiles || 500, options.maxDepth || 8);
        return {
          success: true,
          folderPath: targetFolderPath,
          totalFiles: collectedFiles.length,
          files: collectedFiles,
        };
      } catch (scanError) {
        return { success: false, error: scanError.message };
      }
    });

    // Native Dialog: Select folder and immediately read all real files inside it
    ipcMain.handle("folder:select-and-read", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showOpenDialog !== "function") {
          return { canceled: true, files: [] };
        }
        const openResult = await dialog.showOpenDialog(mainWindow, {
          title: options.title || "Chọn thư mục trên máy tính để quét toàn bộ tệp (Select Folder to Scan)",
          defaultPath: options.defaultPath,
          buttonLabel: options.buttonLabel || "Quét Thư Mục (Scan Folder)",
          properties: ["openDirectory"],
        });
        if (openResult.canceled || !openResult.filePaths || openResult.filePaths.length === 0) {
          return { canceled: true, files: [] };
        }
        const selectedFolderPath = openResult.filePaths[0];
        const collectedFiles = await readRealFilesRecursively(selectedFolderPath, options.maxFiles || 500, options.maxDepth || 8);
        return {
          canceled: false,
          folderPath: selectedFolderPath,
          totalFiles: collectedFiles.length,
          files: collectedFiles,
        };
      } catch (selectAndReadError) {
        displayElectronError("Select & Scan Folder Error", selectAndReadError);
        return { canceled: true, files: [], error: selectAndReadError.message };
      }
    });

    // Native Dialog: Select multiple real files and immediately read their contents
    ipcMain.handle("file:select-and-read", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showOpenDialog !== "function") {
          return { canceled: true, files: [] };
        }
        const openResult = await dialog.showOpenDialog(mainWindow, {
          title: options.title || "Chọn các tệp tin trên máy tính để quét an ninh (Select Files to Scan)",
          defaultPath: options.defaultPath,
          buttonLabel: options.buttonLabel || "Quét Các Tệp (Scan Files)",
          properties: ["openFile", "multiSelections"],
          filters: options.filters || [
            {
              name: "Mã nguồn & Cấu hình (Code & Configs)",
              extensions: ["ts", "tsx", "js", "jsx", "mjs", "json", "yml", "yaml", "md", "html", "sh", "py", "sql", "env"],
            },
            { name: "Tất cả tệp (All Files)", extensions: ["*"] },
          ],
        });

        if (openResult.canceled || !openResult.filePaths || openResult.filePaths.length === 0) {
          return { canceled: true, files: [] };
        }

        const readFiles = [];
        for (const filePath of openResult.filePaths) {
          try {
            const fileStat = await fileSystem.promises.stat(filePath);
            if (!fileStat.isFile() || fileStat.size > 5 * 1024 * 1024) continue;
            const content = await fileSystem.promises.readFile(filePath, "utf8");
            readFiles.push({
              filename: path.basename(filePath),
              content,
              fullPath: filePath,
              size: fileStat.size,
            });
          } catch {
            continue;
          }
        }

        return {
          canceled: false,
          filePaths: openResult.filePaths,
          totalFiles: readFiles.length,
          files: readFiles,
        };
      } catch (selectFilesError) {
        displayElectronError("Select & Scan Files Error", selectFilesError);
        return { canceled: true, files: [], error: selectFilesError.message };
      }
    });

    // Read multiple specified files
    ipcMain.handle("file:read-multiple", async (_event, filePaths = []) => {
      try {
        const readFiles = [];
        for (const filePath of filePaths) {
          try {
            const fileStat = await fileSystem.promises.stat(filePath);
            if (!fileStat.isFile() || fileStat.size > 5 * 1024 * 1024) continue;
            const content = await fileSystem.promises.readFile(filePath, "utf8");
            readFiles.push({
              filename: path.basename(filePath),
              content,
              fullPath: filePath,
              size: fileStat.size,
            });
          } catch {
            continue;
          }
        }
        return { success: true, files: readFiles };
      } catch (readMultipleError) {
        return { success: false, error: readMultipleError.message };
      }
    });

    ipcMain.handle("file:save-dialog", async (_event, options = {}) => {
      try {
        if (!dialog || typeof dialog.showSaveDialog !== "function") {
          return { canceled: true, filePath: "" };
        }
        const saveResult = await dialog.showSaveDialog(mainWindow, {
          title: options.title || "Lưu báo cáo an ninh / tình trạng hệ thống (Save Report)",
          defaultPath: options.defaultPath || "antivirus-health-report.json",
          buttonLabel: options.buttonLabel || "Lưu (Save)",
          filters: options.filters || [
            { name: "Tệp JSON (JSON Report)", extensions: ["json"] },
            { name: "Tệp văn bản (Markdown Report)", extensions: ["md", "txt"] },
          ],
        });

        if (saveResult.canceled || !saveResult.filePath) {
          return { canceled: true, filePath: "" };
        }
        return { canceled: false, filePath: saveResult.filePath };
      } catch (saveDialogError) {
        displayElectronError("Save File Dialog Error", saveDialogError);
        return { canceled: true, filePath: "" };
      }
    });

    ipcMain.handle("file:read", async (_event, targetFilePath) => {
      try {
        if (!targetFilePath || typeof targetFilePath !== "string") {
          return { success: false, error: "Invalid file path" };
        }
        const content = await fileSystem.promises.readFile(targetFilePath, "utf8");
        return { success: true, content, filePath: targetFilePath };
      } catch (readFileError) {
        return { success: false, error: readFileError.message };
      }
    });

    ipcMain.handle("file:write", async (_event, { targetFilePath, fileContentText }) => {
      try {
        if (!targetFilePath || typeof targetFilePath !== "string") {
          return { success: false, error: "Invalid file path" };
        }
        await fileSystem.promises.writeFile(targetFilePath, fileContentText, "utf8");
        return { success: true, filePath: targetFilePath };
      } catch (writeFileError) {
        return { success: false, error: writeFileError.message };
      }
    });

    // Native System Health Telemetry IPC
    ipcMain.handle("system:get-health", () => {
      try {
        const osTotalMemMb = Math.round(os.totalmem() / (1024 * 1024));
        const osFreeMemMb = Math.round(os.freemem() / (1024 * 1024));
        const osUsedMemMb = Math.max(0, osTotalMemMb - osFreeMemMb);
        const memPercent = osTotalMemMb > 0 ? Math.round((osUsedMemMb / osTotalMemMb) * 100) : 0;
        const cpusList = os.cpus() || [];
        const loadAvg = os.loadavg ? os.loadavg() : [0.5, 0.4, 0.3];

        return {
          success: true,
          platform: process.platform,
          arch: process.arch,
          uptimeSeconds: os.uptime(),
          cpu: {
            model: cpusList[0]?.model || "Host CPU",
            cores: cpusList.length || 4,
            loadAvg,
          },
          memory: {
            totalMb: osTotalMemMb,
            usedMb: osUsedMemMb,
            freeMb: osFreeMemMb,
            usagePercent: memPercent,
          },
        };
      } catch (healthError) {
        return { success: false, error: healthError.message };
      }
    });
  } catch (ipcRegistrationError) {
    displayElectronError("Register IPC Handlers Error", ipcRegistrationError);
  }
}

/**
 * Create the primary desktop window
 */
function createMainWindow() {
  try {
    if (!BrowserWindow) {
      console.warn("[Antivirus Electron] BrowserWindow class not available.");
      return null;
    }

    const windowPreloadScriptPath = path.join(__dirname, "preload.cjs");

    mainWindow = new BrowserWindow({
      width: 1440,
      height: 900,
      minWidth: 1024,
      minHeight: 700,
      title: "2-TEK Antivirus & System Health Studio",
      backgroundColor: "#0f172a",
      show: false,
      frame: true,
      webPreferences: {
        preload: windowPreloadScriptPath,
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        webSecurity: true,
      },
    });

    mainWindow.once("ready-to-show", () => {
      try {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.show();
          mainWindow.focus();
        }
      } catch (showError) {
        displayElectronError("Window Show Error", showError);
      }
    });

    mainWindow.on("maximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("window:maximized-change", true);
      }
    });

    mainWindow.on("unmaximize", () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("window:maximized-change", false);
      }
    });

    mainWindow.on("closed", () => {
      mainWindow = null;
    });

    // Load Next.js server URL
    mainWindow.loadURL(ANTIVIRUS_APP_URL).catch((loadUrlError) => {
      console.warn(`[Antivirus Electron] Initial loadURL failed (${ANTIVIRUS_APP_URL}):`, loadUrlError.message);
      setTimeout(() => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.loadURL(ANTIVIRUS_APP_URL).catch((retryError) => {
            displayElectronError("Page Load Error", retryError, `Target URL: ${ANTIVIRUS_APP_URL}`);
          });
        }
      }, 1500);
    });

    return mainWindow;
  } catch (windowCreationError) {
    displayElectronError("Window Creation Error", windowCreationError);
    return null;
  }
}

/**
 * Application Lifecycle Initialization
 */
function initializeAntivirusDesktopApp() {
  try {
    if (!app || typeof app.whenReady !== "function") {
      return;
    }

    app.whenReady().then(() => {
      registerIpcHandlers();
      createMainWindow();

      app.on("activate", () => {
        if (BrowserWindow && BrowserWindow.getAllWindows().length === 0) {
          createMainWindow();
        }
      });
    });

    app.on("window-all-closed", () => {
      if (process.platform !== "darwin") {
        app.quit();
      }
    });
  } catch (lifecycleError) {
    displayElectronError("App Lifecycle Error", lifecycleError);
  }
}

initializeAntivirusDesktopApp();

module.exports = {
  configureAppMetadata,
  displayElectronError,
  readRealFilesRecursively,
  registerIpcHandlers,
  resolveAntivirusPortFromEnv,
};
