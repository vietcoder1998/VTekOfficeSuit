/**
 * Packages/Antivirus/electron/preload.cjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Antivirus & System Health Studio — Electron Preload Bridge
 *
 * Exposes a typed, isolated context bridge interface (window.electronAPI)
 * for secure communication between renderer and main process.
 * ─────────────────────────────────────────────────────────────────────────────
 */

function loadElectronModule() {
  try {
    return require("electron");
  } catch (loadError) {
    console.warn(
      "[Antivirus Preload] Electron module not available in current environment:",
      loadError && loadError.message ? loadError.message : loadError
    );
    return {};
  }
}

const electronModule = loadElectronModule();
const { contextBridge, ipcRenderer } = electronModule;

const electronBridgeApi = {
  isElectron: true,
  platform: process.platform || "linux",

  /**
   * Window Controls
   */
  minimizeWindow: () => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("window:minimize");
      }
      return Promise.resolve(true);
    } catch (minimizeError) {
      console.error("[Antivirus Preload Error] minimizeWindow failed:", minimizeError);
      return Promise.resolve(false);
    }
  },

  maximizeWindow: () => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("window:maximize");
      }
      return Promise.resolve(true);
    } catch (maximizeError) {
      console.error("[Antivirus Preload Error] maximizeWindow failed:", maximizeError);
      return Promise.resolve(false);
    }
  },

  closeWindow: () => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("window:close");
      }
      return Promise.resolve(true);
    } catch (closeError) {
      console.error("[Antivirus Preload Error] closeWindow failed:", closeError);
      return Promise.resolve(false);
    }
  },

  isMaximized: () => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("window:is-maximized");
      }
      return Promise.resolve(false);
    } catch (checkMaximizedError) {
      console.error("[Antivirus Preload Error] isMaximized failed:", checkMaximizedError);
      return Promise.resolve(false);
    }
  },

  onWindowStateChange: (callback) => {
    if (!ipcRenderer || typeof ipcRenderer.on !== "function") {
      return () => {};
    }
    const listener = (_event, isMaximizedState) => {
      try {
        if (typeof callback === "function") {
          callback(Boolean(isMaximizedState));
        }
      } catch (listenerError) {
        console.error("[Antivirus Preload Error] onWindowStateChange listener error:", listenerError);
      }
    };
    ipcRenderer.on("window:maximized-change", listener);
    return () => {
      try {
        ipcRenderer.removeListener("window:maximized-change", listener);
      } catch (removeError) {
        console.error("[Antivirus Preload Error] Failed to remove listener:", removeError);
      }
    };
  },

  /**
   * Native File & Folder Dialogs
   */
  selectFolderDialog: (options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("folder:select-dialog", options);
      }
      return Promise.resolve({ canceled: true, filePaths: [] });
    } catch (selectFolderError) {
      console.error("[Antivirus Preload Error] selectFolderDialog failed:", selectFolderError);
      return Promise.resolve({ canceled: true, filePaths: [] });
    }
  },

  openFileDialog: (options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:open-dialog", options);
      }
      return Promise.resolve({ canceled: true, filePaths: [] });
    } catch (openDialogError) {
      console.error("[Antivirus Preload Error] openFileDialog failed:", openDialogError);
      return Promise.resolve({ canceled: true, filePaths: [] });
    }
  },

  saveFileDialog: (options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:save-dialog", options);
      }
      return Promise.resolve({ canceled: true, filePath: "" });
    } catch (saveDialogError) {
      console.error("[Antivirus Preload Error] saveFileDialog failed:", saveDialogError);
      return Promise.resolve({ canceled: true, filePath: "" });
    }
  },

  scanRealFolder: (targetFolderPath, options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("folder:read-files", { targetFolderPath, options });
      }
      return Promise.resolve({ success: false, error: "IPC unavailable" });
    } catch (scanFolderError) {
      console.error("[Antivirus Preload Error] scanRealFolder failed:", scanFolderError);
      return Promise.resolve({ success: false, error: String(scanFolderError) });
    }
  },

  selectAndScanRealFolder: (options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("folder:select-and-read", options);
      }
      return Promise.resolve({ canceled: true, files: [] });
    } catch (selectAndScanFolderError) {
      console.error("[Antivirus Preload Error] selectAndScanRealFolder failed:", selectAndScanFolderError);
      return Promise.resolve({ canceled: true, files: [] });
    }
  },

  selectAndScanRealFiles: (options = {}) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:select-and-read", options);
      }
      return Promise.resolve({ canceled: true, files: [] });
    } catch (selectAndScanFilesError) {
      console.error("[Antivirus Preload Error] selectAndScanRealFiles failed:", selectAndScanFilesError);
      return Promise.resolve({ canceled: true, files: [] });
    }
  },

  readMultipleFiles: (filePaths = []) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:read-multiple", filePaths);
      }
      return Promise.resolve({ success: false, error: "IPC unavailable" });
    } catch (readMultipleError) {
      console.error("[Antivirus Preload Error] readMultipleFiles failed:", readMultipleError);
      return Promise.resolve({ success: false, error: String(readMultipleError) });
    }
  },

  readFile: (targetFilePath) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:read", targetFilePath);
      }
      return Promise.resolve({ success: false, error: "IPC unavailable" });
    } catch (readFileError) {
      console.error("[Antivirus Preload Error] readFile failed:", readFileError);
      return Promise.resolve({ success: false, error: String(readFileError) });
    }
  },

  writeFile: (targetFilePath, fileContentText) => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("file:write", { targetFilePath, fileContentText });
      }
      return Promise.resolve({ success: false, error: "IPC unavailable" });
    } catch (writeFileError) {
      console.error("[Antivirus Preload Error] writeFile failed:", writeFileError);
      return Promise.resolve({ success: false, error: String(writeFileError) });
    }
  },

  /**
   * Native System Health Telemetry
   */
  getSystemHealth: () => {
    try {
      if (ipcRenderer && typeof ipcRenderer.invoke === "function") {
        return ipcRenderer.invoke("system:get-health");
      }
      return Promise.resolve({ success: false, error: "IPC unavailable" });
    } catch (healthError) {
      console.error("[Antivirus Preload Error] getSystemHealth failed:", healthError);
      return Promise.resolve({ success: false, error: String(healthError) });
    }
  },
};

if (contextBridge && typeof contextBridge.exposeInMainWorld === "function") {
  try {
    contextBridge.exposeInMainWorld("electronAPI", electronBridgeApi);
  } catch (exposeError) {
    console.error("[Antivirus Preload Error] Failed to expose electronAPI via contextBridge:", exposeError);
    if (typeof window !== "undefined") {
      window.electronAPI = electronBridgeApi;
    }
  }
} else if (typeof window !== "undefined") {
  window.electronAPI = electronBridgeApi;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { electronBridgeApi };
}
