/**
 * Packages/Word/electron/runner.cjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Word Document Studio — Electron Development Orchestrator
 *
 * Checks/starts the Next.js dev server on port 3025, waits for HTTP readiness,
 * and launches the Electron desktop application.
 * Conforms to: Electron Single Try-Catch & Mandatory Error Display Rule
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { spawn } = require("node:child_process");
const http = require("node:http");
const path = require("node:path");
const fileSystem = require("node:fs");

function resolveWordPortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsedPort = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsedPort) && parsedPort > 0) {
          return parsedPort;
        }
      }
      if (process.env.WORD_PORT) {
        const parsedWordPort = parseInt(process.env.WORD_PORT, 10);
        if (!Number.isNaN(parsedWordPort) && parsedWordPort > 0) {
          return parsedWordPort;
        }
      }
    }

    const wordRootDirectory = path.resolve(__dirname, "..");
    const candidateEnvironmentFiles = [
      path.join(wordRootDirectory, ".env"),
      path.join(wordRootDirectory, ".env.local"),
      path.join(wordRootDirectory, ".env.development"),
    ];

    for (const candidateEnvironmentFilePath of candidateEnvironmentFiles) {
      if (fileSystem.existsSync(candidateEnvironmentFilePath)) {
        const fileContentString = fileSystem.readFileSync(candidateEnvironmentFilePath, "utf8");
        const fileLines = fileContentString.split(/\r?\n/);
        for (const singleLine of fileLines) {
          const trimmedLine = singleLine.trim();
          if (trimmedLine.startsWith("#") || !trimmedLine.includes("=")) {
            continue;
          }
          const separatorIndex = trimmedLine.indexOf("=");
          const variableKey = trimmedLine.slice(0, separatorIndex).trim();
          if (variableKey === "PORT" || variableKey === "WORD_PORT") {
            const rawVariableValue = trimmedLine.slice(separatorIndex + 1).trim();
            const cleanVariableValue = rawVariableValue.replace(/^["']|["']$/g, "");
            const parsedPort = parseInt(cleanVariableValue, 10);
            if (!Number.isNaN(parsedPort) && parsedPort > 0) {
              return parsedPort;
            }
          }
        }
      }
    }
  } catch (resolvePortError) {
    console.error("[Word Runner Error] Failed resolving port from env:", resolvePortError);
  }

  return 3025;
}

const WORD_TARGET_PORT = resolveWordPortFromEnv();
const WORD_DEV_SERVER_URL = `http://localhost:${WORD_TARGET_PORT}`;
const MAXIMUM_POLL_ATTEMPTS = 120;
const POLL_INTERVAL_MILLISECONDS = 500;

let nextServerProcess = null;
let electronChildProcess = null;

function checkServerReady(targetUrl = WORD_DEV_SERVER_URL) {
  try {
    return new Promise((resolve) => {
      const request = http.get(targetUrl, (response) => {
        resolve(true);
        response.resume();
      });

      request.on("error", () => {
        if (targetUrl.includes("localhost:")) {
          const fallbackUrl = targetUrl.replace("localhost:", "127.0.0.1:");
          const fallbackRequest = http.get(fallbackUrl, (fallbackResponse) => {
            resolve(true);
            fallbackResponse.resume();
          });
          fallbackRequest.on("error", () => resolve(false));
          fallbackRequest.setTimeout(800, () => {
            fallbackRequest.destroy();
            resolve(false);
          });
        } else {
          resolve(false);
        }
      });

      request.setTimeout(800, () => {
        request.destroy();
        resolve(false);
      });
    });
  } catch (checkError) {
    console.error("[Word Runner Error] checkServerReady unexpected failure:", checkError);
    return Promise.resolve(false);
  }
}

async function waitForServer(targetUrl = WORD_DEV_SERVER_URL) {
  console.log(`[Word Runner] Waiting for dev server at ${targetUrl}...`);
  for (let attemptNumber = 1; attemptNumber <= MAXIMUM_POLL_ATTEMPTS; attemptNumber += 1) {
    const isReady = await checkServerReady(targetUrl);
    if (isReady) {
      console.log(`[Word Runner] Dev server is ready at ${targetUrl} (attempt ${attemptNumber})`);
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MILLISECONDS));
  }
  console.warn(`[Word Runner] Server did not become ready after ${MAXIMUM_POLL_ATTEMPTS} attempts, launching anyway.`);
  return false;
}

function resolveElectronCommand(wordDirectory) {
  const isWindows = process.platform === "win32";
  const workspaceRootDirectory = path.resolve(wordDirectory, "..", "..");

  const directBinaryCandidates = [
    path.join(wordDirectory, "node_modules", "electron", "dist", isWindows ? "electron.exe" : "electron"),
    path.join(workspaceRootDirectory, "node_modules", "electron", "dist", isWindows ? "electron.exe" : "electron"),
    path.join(wordDirectory, "node_modules", ".bin", isWindows ? "electron.cmd" : "electron"),
    path.join(workspaceRootDirectory, "node_modules", ".bin", isWindows ? "electron.cmd" : "electron"),
  ];

  for (const candidateBinaryPath of directBinaryCandidates) {
    if (fileSystem.existsSync(candidateBinaryPath)) {
      return { command: candidateBinaryPath, argsPrefix: [] };
    }
  }

  const cliJsCandidates = [
    path.join(wordDirectory, "node_modules", "electron", "cli.js"),
    path.join(workspaceRootDirectory, "node_modules", "electron", "cli.js"),
  ];

  for (const candidateCliPath of cliJsCandidates) {
    if (fileSystem.existsSync(candidateCliPath)) {
      return { command: process.execPath, argsPrefix: [candidateCliPath] };
    }
  }

  return { command: isWindows ? "npx.cmd" : "npx", argsPrefix: ["electron"] };
}

async function startDevelopmentWorkflow() {
  const wordDirectory = path.resolve(__dirname, "..");
  const isAlreadyRunning = await checkServerReady(WORD_DEV_SERVER_URL);

  if (!isAlreadyRunning) {
    console.log(`[Word Runner] Starting Word Next.js server on port ${WORD_TARGET_PORT}...`);
    const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";

    nextServerProcess = spawn(npmCommand, ["run", "dev"], {
      cwd: wordDirectory,
      stdio: "inherit",
      env: {
        ...process.env,
        PORT: String(WORD_TARGET_PORT),
        WORD_PORT: String(WORD_TARGET_PORT),
      },
    });

    nextServerProcess.on("error", (spawnError) => {
      console.error("[Word Runner] Failed to spawn Next.js dev server:", spawnError);
    });
  } else {
    console.log(`[Word Runner] Dev server is already active on port ${WORD_TARGET_PORT}`);
  }

  await waitForServer(WORD_DEV_SERVER_URL);

  const { command: electronExecutableCommand, argsPrefix: electronArgumentsPrefix } =
    resolveElectronCommand(wordDirectory);

  console.log(`[Word Runner] Launching Electron with ${electronExecutableCommand}...`);
  const finalElectronArguments = [...electronArgumentsPrefix, "."];

  electronChildProcess = spawn(electronExecutableCommand, finalElectronArguments, {
    cwd: wordDirectory,
    stdio: "inherit",
    env: {
      ...process.env,
      PORT: String(WORD_TARGET_PORT),
      WORD_PORT: String(WORD_TARGET_PORT),
      ELECTRON_IS_DEV: "1",
    },
  });

  electronChildProcess.on("exit", (exitCode) => {
    console.log(`[Word Runner] Electron exited with code ${exitCode}`);
    if (nextServerProcess && !nextServerProcess.killed) {
      nextServerProcess.kill();
    }
    process.exit(exitCode || 0);
  });

  const cleanupSignalHandler = () => {
    if (electronChildProcess && !electronChildProcess.killed) {
      electronChildProcess.kill();
    }
    if (nextServerProcess && !nextServerProcess.killed) {
      nextServerProcess.kill();
    }
    process.exit(0);
  };

  process.on("SIGINT", cleanupSignalHandler);
  process.on("SIGTERM", cleanupSignalHandler);
}

if (require.main === module) {
  startDevelopmentWorkflow().catch((runnerError) => {
    console.error("[Word Runner Error] Execution failed:", runnerError);
    process.exit(1);
  });
}

module.exports = {
  resolveWordPortFromEnv,
  checkServerReady,
  resolveElectronCommand,
};
