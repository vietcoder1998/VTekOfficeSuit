#!/bin/bash
# 2-TEK Dual-Start Launcher: Next.js Standalone + Electron App View
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
if [ -f "electron/runner.cjs" ]; then
  exec node electron/runner.cjs "$@"
elif command -v electron >/dev/null 2>&1 && [ -f "electron/main.cjs" ]; then
  exec electron electron/main.cjs "$@"
elif [ -f "electron/main.cjs" ]; then
  exec npx electron electron/main.cjs "$@"
else
  exec node server.js "$@"
fi
