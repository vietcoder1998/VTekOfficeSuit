// 2-TEK Standalone Next.js Server Wrapper
const path = require("node:path");
const fs = require("node:fs");

process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3020";
process.env.HOSTNAME = process.env.HOSTNAME || "0.0.0.0";

const candidateServerPaths = [
  path.join(__dirname, "server.js"),
  path.join(__dirname, "packages", "Hub", "server.js"),
  path.join(__dirname, ".next", "standalone", "packages", "Hub", "server.js"),
  path.join(__dirname, ".next", "standalone", "server.js"),
  path.join(__dirname, "server-standalone.js"),
  "/home/tranduyviet/Projects/2tek-office-packs/packages/Hub/.next/standalone/packages/Hub/server.js",
  "/home/tranduyviet/Projects/2tek-office-packs/packages/Hub/.next/standalone/server.js",
];

let standaloneExecuted = false;
for (const candidatePath of candidateServerPaths) {
  if (candidatePath && candidatePath !== __filename && fs.existsSync(candidatePath)) {
    try {
      require(candidatePath);
      standaloneExecuted = true;
      break;
    } catch (candidateError) {
      console.warn(
        "> Standalone candidate failed to load (" + candidatePath + "):",
        candidateError && candidateError.message ? candidateError.message : candidateError
      );
    }
  }
}

if (!standaloneExecuted) {
  const http = require("node:http");
  const port = parseInt(process.env.PORT, 10);
  const hostname = process.env.HOSTNAME;
  const server = http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<!DOCTYPE html><html><head><title>2-TEK Hub Desktop</title></head><body><h1>2-TEK Hub Desktop</h1><p>Universal application launcher, desktop manager, and process hub.</p></body></html>`);
  });
  server.listen(port, hostname, () => {
    console.log(`> 2-TEK Hub Desktop standalone running on http://${hostname}:${port}`);
  });
}
